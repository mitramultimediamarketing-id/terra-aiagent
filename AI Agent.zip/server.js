require('dotenv').config();
const express = require('express'), cors = require('cors'), cron = require('node-cron');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { createClient } = require('@supabase/supabase-js');
const app = express();
// CORS: ALLOWED_ORIGINS di .env, pisahkan koma. Contoh: https://nama.netlify.app,*.netlify.app
// Kosong = semua origin diizinkan (hanya untuk testing). localhost selalu diizinkan.
const ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim().replace(/\/$/, '')).filter(Boolean);
const originOk = o => !o || !ORIGINS.length || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o) ||
  ORIGINS.some(a => a.startsWith('*.') ? new URL(o).hostname.endsWith(a.slice(1)) : a === o);
app.use(cors({ origin: (o, cb) => originOk(o) ? cb(null, true) : cb(new Error('CORS blocked: ' + o)),
  methods: ['GET', 'POST', 'OPTIONS'], allowedHeaders: ['Content-Type'], maxAge: 86400 }));
app.use(express.json());
app.get('/', (q, r) => r.send('TERRA W3B backend OK'));
app.get('/health', (q, r) => r.json({ ok: true }));   // untuk ping agar Render tidak tidur

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const db = process.env.SUPABASE_URL ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY) : null;
const TABLES = ['chats_ceo','manager_logs','finance_logs','crypto_logs','marketing_products','wa_histories','prompts','media_assets','upload_schedules'];
const NAMES = ['CEO','Manager','Finance','Crypto-Analyst','Marketing-Analyst','Ads-Service','Client-Service','Affiliate-Scripter','Animation-Scripter','Design-Creator','Video-Creator','Content-Uploader'];

const S = { paused: true, resetAt: Date.now(), agents: {}, ceo: [], wa: {}, part: 1 };
NAMES.forEach(n => S.agents[n] = { status: '😴', alert: false, data: null });
const setAll = s => NAMES.forEach(n => S.agents[n].status = s);
const save = (t, payload) => db && db.from(t).insert({ payload }).then(() => {}, e => console.log('db', e.message));

async function ask(prompt, system, json) {
  const m = genAI.getGenerativeModel({ model: MODEL, systemInstruction: system,
    generationConfig: json ? { responseMimeType: 'application/json' } : undefined });
  const t = (await m.generateContent(prompt)).response.text();
  return json ? JSON.parse(t) : t;
}

// Jalankan 1 pekerjaan agen: status 😐 -> selesai 😴 + badge ⚠️
async function job(name, table, fn) {
  if (S.paused) return;
  const a = S.agents[name]; a.status = '😐';
  try { a.data = await fn(); a.alert = true; save(table, { agent: name, ...a.data }); }
  catch (e) { a.data = { lines: ['Error: ' + e.message] }; }
  a.status = '😴';
}

async function sheetCSV() {
  const r = await fetch(`https://docs.google.com/spreadsheets/d/${process.env.SHEET_ID}/export?format=csv`);
  if (!r.ok) throw new Error('Sheet tidak bisa dibaca (set share: anyone with link)');
  return (await r.text()).slice(0, 12000);
}

const jobs = {
  finance: () => job('Finance', 'finance_logs', async () => {
    const j = await ask('Dari data CSV ini hitung & balas JSON {"revenue":"","working_capital":"","retained_earnings":"","cost":"","net_profit":""} (angka Rupiah). Revenue=Jasa Iklan+Affiliate Shopee/Tiktok, Working Capital=Total Marketing Balance, Retained Earnings=Total Affiliate, Cost=Pengeluaran+Biaya CS & Operator.\n' + await sheetCSV(), 'Kamu penasihat keuangan TERRA.', true);
    return { lines: ['Revenue : Rp' + j.revenue, 'Working Capital : Rp' + j.working_capital, 'Retained Earnings : Rp' + j.retained_earnings, 'Cost : Rp' + j.cost, 'Net Profit : Rp' + j.net_profit] };
  }),
  crypto: () => job('Crypto-Analyst', 'crypto_logs', async () => {
    const p = await (await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true')).json().catch(() => ({}));
    const fg = await (await fetch('https://api.alternative.me/fng/')).json().catch(() => ({}));
    const t = await ask('Data live: ' + JSON.stringify(p) + ' FearGreed: ' + JSON.stringify(fg.data && fg.data[0]) + '. Buat analisis BTC (TA MA/EMA/RSI/MACD/AHR999, berita & data ekonomi US/JP secara umum). Output: 1) Rekomendasi Futures (Entry, TP, SL) 2) Rekomendasi Spot (harga beli). Ringkas, tanpa jaminan profit.', 'Kamu Crypto Analyst TERRA.');
    return { lines: t.split('\n').filter(Boolean) };
  }),
  daily: async () => {
    await job('Marketing-Analyst', 'marketing_products', async () => ({
      products: (await ask('Riset 3 produk terlaris TikTok Shop kategori peralatan/elektronik dapur harga Rp10.000-Rp40.000. JSON {"products":[{"name":""}]}', 'Kamu Marketing Analyst.', true)).products.map(p => ({ name: p.name, image: '' })) }));
    const names = ((S.agents['Marketing-Analyst'].data || {}).products || []).map(p => p.name);
    await job('Affiliate-Scripter', 'prompts', async () => {
      const j = await ask('Produk: ' + names.join(', ') + '. Buat JSON {"video":[3 prompt video affiliate 10 detik 9:16 tanpa wajah VO cewek teks "by@mitramultimedia.id"],"design":[3 prompt design Instagram 3:4 Jasa Pembuatan Video Iklan tema produk]}', 'Kamu Affiliate Scripter.', true);
      return { prompts: [...j.video, ...j.design], video: j.video, design: j.design };
    });
    const A = S.agents['Affiliate-Scripter'].data || {};
    await job('Animation-Scripter', 'prompts', async () => ({ prompts: [await ask(`1 prompt video 10 detik 9:16, Anime Indonesia Horor, karakter dewasa, Part ${S.part++} (lanjutan cerita).`, 'Kamu Animation Scripter.')] }));
    // Catatan: generator gambar/video (Imagen/Veo) berbayar -> disini antrian prompt saja, sambungkan API-nya di sini.
    await job('Design-Creator', 'media_assets', async () => ({ lines: (A.design || []).map(p => 'Antrian generate gambar: ' + p) }));
    await job('Video-Creator', 'media_assets', async () => ({ lines: [...(A.video || []), ...(S.agents['Animation-Scripter'].data || {}).prompts || []].map(p => 'Antrian generate video: ' + p) }));
    await job('Content-Uploader', 'upload_schedules', async () => {
      const r = (a, b) => `${String(a + Math.floor(Math.random() * (b - a))).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`;
      return { lines: ['Video Affiliate 1 -> TikTok & Shopee Video ' + r(11, 13), 'Video Affiliate 2 -> TikTok & Shopee Video ' + r(17, 19), 'Video Affiliate 3 -> TikTok & Shopee Video ' + r(20, 22), 'Design x3 -> Instagram Feed (jam acak) ' + r(8, 20), 'Video Animasi -> YouTube Studio ' + r(18, 21)] };
    });
  }
};

// ---- API ----
app.get('/api/state', (q, r) => r.json({ paused: S.paused, resetAt: S.resetAt, agents: S.agents }));
app.post('/api/pause', (q, r) => { S.paused = !!q.body.paused; setAll(S.paused ? '😴' : '🙂'); r.json({ ok: true }); });
app.post('/api/open', (q, r) => { const a = S.agents[q.body.name]; if (a) a.alert = false; r.json({ ok: true }); });
app.post('/api/restart', (q, r) => { NAMES.forEach(n => { if (S.agents[n].status === '😐') S.agents[n].status = '🙂'; }); save('manager_logs', { restart: new Date() }); r.json({ ok: true }); });
app.get('/api/ceo/history', (q, r) => r.json(S.ceo));
app.post('/api/ceo', async (q, r) => {
  const time = () => new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' }).replace(':', '.');
  const msg = String(q.body.message || '');
  S.ceo.push({ me: false, text: msg, time: time() });
  try {
    const sys = 'Kamu adalah CEO TERRA, otak kepala perusahaan. Berhak menerima instruksi pengguna dan memberikan perintah eksekusi ke tim AI Agent. Fundamental Perusahaan TERRA: Didirikan 2022 oleh Founder MUHAMMAD ABDUL AZIZ (Shareholder 70% Mitra Multimedia Marketing & TERRA), YOAN EKA BAGAS PRASETYO (10%), MUHAMMAD FAJRI (5%), AXCEL FEBRIAN ANUGRAH (5%). Visi Misi: Merancang teknologi sistem terbarukan untuk perdagangan efisien, fleksibel, omset tinggi dan stabil.';
    const c = msg.match(/^\/(\S+)\s*([\s\S]*)/); let prompt = msg;
    if (c) {
      const n = NAMES.find(x => x.toLowerCase().replace(/-/g, '') === c[1].toLowerCase().replace(/-/g, ''));
      if (n) prompt = `Teruskan instruksi ke agen ${n}: "${c[2]}". Data agen saat ini: ${JSON.stringify(S.agents[n].data || {}).slice(0, 1500)}. Balas diawali "/${n} ".`;
    }
    const a = S.agents.CEO; a.status = S.paused ? '😴' : '😐';
    const reply = await ask(prompt, sys); a.status = S.paused ? '😴' : '🙂';
    S.ceo.push({ me: true, text: reply, time: time() }); save('chats_ceo', { msg, reply });
    r.json({ reply });
  } catch (e) { r.json({ reply: 'Error: ' + e.message }); }
});

// ---- WhatsApp (Baileys) ----
const CS = 'Kamu Sales Consultant ramah TERRA (Mitra Multimedia) jasa video iklan. Panggil klien "kak/kk". Harga: 0-15 dtk Rp74.900; 16-30 dtk Rp84.900; 31-45 dtk Rp94.900; 46-60 dtk Rp104.900; >60 dtk tambah Rp50.000 per 30 dtk. Tanyakan 8 poin: jenis usaha, durasi, model (storytelling/motion graphic), bahan/logo, script, ratio (9:16/16:9/3:4), VO (L/P). Bayar: Shopee Checkout https://s.shopee.co.id/1ApXMZcEb, SeaBank 901085557808, ShopeePay 083805281937 a.n MUHAMMAD ABDUL AZIZ. Setelah bukti transfer terverifikasi, kirim Form Rangkuman Order.';
async function startWA() {
  const { default: mk, useMultiFileAuthState, DisconnectReason } = await import('@whiskeysockets/baileys');
  const { state, saveCreds } = await useMultiFileAuthState('wa_auth');
  const sock = mk({ auth: state });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', u => {
    if (u.qr) require('qrcode-terminal').generate(u.qr, { small: true });
    if (u.connection === 'open') console.log('WhatsApp tersambung');
    if (u.connection === 'close' && (u.lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut)) startWA();
  });
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0]; if (!m.message || m.key.fromMe || S.paused) return;
    const jid = m.key.remoteJid, text = m.message.conversation || m.message.extendedTextMessage?.text; if (!text || jid.endsWith('@g.us')) return;
    const h = S.wa[jid] = S.wa[jid] || []; h.push({ me: false, text }); const a = S.agents['Client-Service']; a.status = '😐';
    try {
      const reply = await ask(h.slice(-20).map(x => (x.me ? 'CS: ' : 'Klien: ') + x.text).join('\n'), CS);
      await sock.sendMessage(jid, { text: reply }); h.push({ me: true, text: reply });
      a.data = { chats: S.wa }; a.alert = true; save('wa_histories', { jid, text, reply });
    } catch (e) { console.log('wa', e.message); }
    a.status = S.paused ? '😴' : '🙂';
  });
}

// ---- Cron (zona WIB) ----
const tz = { timezone: 'Asia/Jakarta' };
cron.schedule('0 9 * * *', () => { jobs.finance(); jobs.daily(); }, tz);
cron.schedule('0 10 * * *', () => jobs.crypto(), tz);
cron.schedule('0 0 * * *', async () => {            // reset database tiap 24 jam
  if (db) for (const t of TABLES) await db.from(t).delete().gte('id', 0);
  NAMES.forEach(n => S.agents[n] = { status: S.paused ? '😴' : '🙂', alert: false, data: null });
  S.ceo = []; S.wa = {}; S.resetAt = Date.now(); console.log('Database di-reset');
}, tz);

// Uji manual tanpa menunggu jam: /api/run/finance | crypto | daily
app.post('/api/run/:j', (q, r) => { jobs[q.params.j] ? (jobs[q.params.j](), r.json({ ok: true })) : r.status(404).json({ ok: false }); });

app.listen(process.env.PORT || 3000, () => { console.log('Server: http://localhost:' + (process.env.PORT || 3000)); startWA().catch(e => console.log('WA off:', e.message)); });
