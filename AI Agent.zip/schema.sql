-- Jalankan di Supabase > SQL Editor
do $$
declare t text;
begin
  foreach t in array array['chats_ceo','manager_logs','finance_logs','crypto_logs','marketing_products','wa_histories','prompts','media_assets','upload_schedules']
  loop
    execute format('create table if not exists %I (id bigint generated always as identity primary key, payload jsonb not null, created_at timestamptz default now())', t);
  end loop;
end $$;
